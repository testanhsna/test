function closesuccess(){
   document.getElementById('success').style.display = "none";
}
function closedanger(){
   document.getElementById('danger').style.display = "none";
}
function closeinfo(){
   document.getElementById('info').style.display = "none";
}
function closewarning(){
   document.getElementById('warning').style.display = "none";
}