function collapse1(){
	document.getElementById('collapse1').style.display = "block";
	document.getElementById('collapse2').style.display = "none";
	document.getElementById('collapse3').style.display = "none";
}
function collapse2(){
	document.getElementById('collapse1').style.display = "none";
	document.getElementById('collapse2').style.display = "block";
	document.getElementById('collapse3').style.display = "none";
}
function collapse3(){
	document.getElementById('collapse1').style.display = "none";
	document.getElementById('collapse2').style.display = "none";
	document.getElementById('collapse3').style.display = "block";
}