function dropdownopen1(){
	document.getElementById('dropdown1').style.display = "block";
	document.getElementById('dropdownopen1').style.display = "none";
	document.getElementById('dropdownclose1').style.display = "block";
}
function dropdownclose1(){
	document.getElementById('dropdown1').style.display = "none";
	document.getElementById('dropdownopen1').style.display = "block";
	document.getElementById('dropdownclose1').style.display = "none";
}
function dropdownopen2(){
	document.getElementById('dropdown2').style.display = "block";
	document.getElementById('dropdownopen2').style.display = "none";
	document.getElementById('dropdownclose2').style.display = "block";
}
function dropdownclose2(){
	document.getElementById('dropdown2').style.display = "none";
	document.getElementById('dropdownopen2').style.display = "block";
	document.getElementById('dropdownclose2').style.display = "none";
}