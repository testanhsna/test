function opendialog1(){
	document.getElementById('dialog1').style.display = "block";
}
function closedialog1(){
	document.getElementById('dialog1').style.display = "none";
}
function opendialog2(){
	document.getElementById('dialog2').style.display = "block";
}
function closedialog2(){
	document.getElementById('dialog2').style.display = "none";
}
function opendialog3(){
	document.getElementById('dialog3').style.display = "block";
}
function closedialog3(){
	document.getElementById('dialog3').style.display = "none";
}