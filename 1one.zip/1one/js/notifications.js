function opennotification1(){
	document.getElementById('notification1').style.display = "block";
}
function closenotification1(){
	document.getElementById('notification1').style.display = "none";
}
function opennotification2(){
	document.getElementById('notification2').style.display = "block";
}
function closenotification2(){
	document.getElementById('notification2').style.display = "none";
}
function opennotification3(){
	document.getElementById('notification3').style.display = "block";
}
function closenotification3(){
	document.getElementById('notification3').style.display = "none";
}
function opennotification4(){
	document.getElementById('notification4').style.display = "block";
}
function closenotification4(){
	document.getElementById('notification4').style.display = "none";
}