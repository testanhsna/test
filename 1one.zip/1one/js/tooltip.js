function tooltiptopopen(){
   document.getElementById('tooltiptop').style.display = "block";
}
function tooltiptopclose(){
   document.getElementById('tooltiptop').style.display = "none";
}
function tooltipleftopen(){
   document.getElementById('tooltipleft').style.display = "block";
}
function tooltipleftclose(){
   document.getElementById('tooltipleft').style.display = "none";
}
function tooltipbottomopen(){
   document.getElementById('tooltipbottom').style.display = "block";
}
function tooltipbottomclose(){
   document.getElementById('tooltipbottom').style.display = "none";
}
function tooltiprightopen(){
   document.getElementById('tooltipright').style.display = "block";
}
function tooltiprightclose(){
   document.getElementById('tooltipright').style.display = "none";
}